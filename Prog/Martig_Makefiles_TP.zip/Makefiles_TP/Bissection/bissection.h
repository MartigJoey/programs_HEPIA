#ifndef BISSECTION_H
#define BISSECTION_H
int getSign(double value);
double g(double x);
int bissect(double a, double b, double epsilon, double *zero);

#endif